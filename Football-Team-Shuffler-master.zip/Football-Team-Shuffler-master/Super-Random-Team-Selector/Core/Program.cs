﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Super_Random {
    class Program
    {
        static void Main(string[] args)
        {
            List<FootballPlayer> footballPlayers = new List<FootballPlayer>();
            InitFootballPlayerList(footballPlayers);

            Console.WriteLine("Before");

            footballPlayers.ForEach(f => Console.WriteLine(String.Format("Full Name: {0}  | Number: {1}", f.FirstName,  f.Number)));

            footballPlayers.Shuffle();

            List<FootballPlayer> firstTeam = new List<FootballPlayer>();
            List<FootballPlayer> secondTeam = new List<FootballPlayer>();
            for (var i = 0; i < footballPlayers.Count; i++)
            {
                if (i % 2 == 0)
                {
                    firstTeam.Add(footballPlayers[i]);
                }
                else
                {
                    secondTeam.Add(footballPlayers[i]);
                }
            }

            firstTeam.Shuffle();
            secondTeam.Shuffle();

            FootballPlayer firstTeamGoalkeeper = firstTeam[0];
            FootballPlayer secondTeamGoalkeeper = secondTeam[0];
              Console.WriteLine("\nAfter");
            Console.WriteLine("First Team:");
            firstTeam.ForEach(f => Console.WriteLine(String.Format("Full Name: {0}  | Number: {1}", f.FirstName, f.Number)));
            Console.WriteLine("First Team Goalkeeper: Full Name: {0} ", firstTeamGoalkeeper.FirstName);

          
            Console.WriteLine("\nSecond Team:");
            secondTeam.ForEach(f => Console.WriteLine(String.Format("Full Name: {0}  | Number: {1}", f.FirstName,  f.Number)));
            Console.WriteLine("Second Team Goalkeeper: Full Name: {0} ", secondTeamGoalkeeper.FirstName);
        }

        private static void InitFootballPlayerList(List<FootballPlayer> list)
        {
            list.Add(new FootballPlayer("HAYK", 1));
            list.Add(new FootballPlayer("DAVID", 7));
            list.Add(new FootballPlayer("MERI",   10));
            list.Add(new FootballPlayer("ARPINE",   17));
            list.Add(new FootballPlayer("MISHA",  8));
            list.Add(new FootballPlayer("TIGRAN",  24));
            list.Add(new FootballPlayer("GRIGOR", 12));
            list.Add(new FootballPlayer("XACHIK", 16));
            list.Add(new FootballPlayer("STYPA", 4));
            list.Add(new FootballPlayer("VARDUHI", 5));
            list.Add(new FootballPlayer("LYOV", 11));
            list.Add(new FootballPlayer("ASTXIK", 2));
            list.Add(new FootballPlayer("MARGAR", 13));
            list.Add(new FootballPlayer("RAZMIK", 18));
          
        }
    }
     public class Person
    {
        public string FirstName { get; set; }

        public Person(string firstName)
        {
            FirstName = firstName;
            
        }

    }
    public class FootballPlayer : Person
    {
        public int Number { get; set; }
        public FootballPlayer(string firstName, int number)
            : base(firstName)
        {
            this.Number = number;
        }
    }
}

